create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null unique,
  role text not null check (role in ('owner', 'admin', 'sub_admin', 'user')) default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.divisions (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  is_active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_divisions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  division_id uuid not null references public.divisions(id) on delete cascade,
  primary key (user_id, division_id)
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  roll_number integer not null,
  student_name text not null,
  division_id uuid not null references public.divisions(id) on delete cascade,
  is_active boolean not null default true,
  admission_date date,
  extra_data jsonb default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (division_id, roll_number)
);

create index if not exists idx_students_division_active on public.students (division_id, is_active);
create index if not exists idx_students_name on public.students (student_name);
create index if not exists idx_users_division on public.user_divisions (division_id);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  division_id uuid not null references public.divisions(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  date_taken date not null,
  present boolean not null,
  marked_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (division_id, student_id, date_taken)
);

create table if not exists public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id),
  action text not null,
  details jsonb default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.backup_jobs (
  id uuid primary key default gen_random_uuid(),
  created_by uuid references public.profiles(id),
  file_name text not null,
  backup_type text not null,
  status text not null default 'queued',
  created_at timestamptz not null default now()
);

create table if not exists public.user_permissions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  permission_key text not null check (
    permission_key in (
      'view_divisions',
      'take_attendance',
      'view_attendance_history',
      'add_students',
      'edit_students',
      'delete_students',
      'add_divisions',
      'delete_divisions',
      'view_activity_logs',
      'manage_backups'
    )
  ),
  assigned_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  primary key (user_id, permission_key)
);

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', 'New User'),
    new.email,
    'user'
  )
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer set search_path = public, pg_temp;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
