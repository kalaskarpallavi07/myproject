create table if not exists public.user_permissions (
  user_id uuid not null references public.profiles(id) on delete cascade,
  permission_key text not null check (
    permission_key in (
      'view_divisions',
      'take_attendance',
      'view_attendance_history',
      'add_students',
      'edit_students',
      'delete_students',
      'add_divisions',
      'delete_divisions',
      'view_activity_logs',
      'manage_backups'
    )
  ),
  assigned_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  primary key (user_id, permission_key)
);

alter table public.profiles enable row level security;
alter table public.divisions enable row level security;
alter table public.user_divisions enable row level security;
alter table public.user_permissions enable row level security;
alter table public.students enable row level security;
alter table public.attendance_records enable row level security;
alter table public.activity_logs enable row level security;
alter table public.backup_jobs enable row level security;

create or replace function public.current_user_role()
returns text
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select p.role from public.profiles p where p.id = auth.uid()
$$;

create or replace function public.has_division_access(target_division uuid)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select public.current_user_role() in ('owner', 'admin')
    or exists (
      select 1
      from public.user_divisions ud
      where ud.user_id = auth.uid()
        and ud.division_id = target_division
    )
$$;

create or replace function public.has_permission(
  requested_permission text,
  target_division uuid default null
)
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select case
    when public.current_user_role() in ('owner', 'admin') then true
    when target_division is not null
      and not public.has_division_access(target_division) then false
    when public.current_user_role() = 'user' then requested_permission in (
      'view_divisions',
      'take_attendance',
      'view_attendance_history'
    )
    when public.current_user_role() = 'sub_admin' then exists (
      select 1
      from public.user_permissions up
      where up.user_id = auth.uid()
        and up.permission_key = requested_permission
    )
    else false
  end
$$;

revoke all on function public.current_user_role() from public;
revoke all on function public.has_division_access(uuid) from public;
revoke all on function public.has_permission(text, uuid) from public;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.has_division_access(uuid) to authenticated;
grant execute on function public.has_permission(text, uuid) to authenticated;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles (id, full_name, email, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', 'New User'),
    new.email,
    'user'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

drop policy if exists "Owner can manage all rows" on public.profiles;
drop policy if exists "Users can view own profile" on public.profiles;
drop policy if exists "Users can view assigned divisions" on public.divisions;
drop policy if exists "Admins can manage divisions" on public.divisions;
drop policy if exists "Users can view assigned students" on public.students;
drop policy if exists "Admins can manage students" on public.students;
drop policy if exists "Users can write attendance for assigned divisions" on public.attendance_records;
drop policy if exists "Users can read attendance from assigned divisions" on public.attendance_records;
drop policy if exists "Admins can manage activity logs" on public.activity_logs;
drop policy if exists "Owners can handle backups" on public.backup_jobs;

drop policy if exists "profiles_read_access" on public.profiles;
drop policy if exists "profiles_owner_manage" on public.profiles;
drop policy if exists "divisions_read_access" on public.divisions;
drop policy if exists "divisions_add_access" on public.divisions;
drop policy if exists "divisions_update_access" on public.divisions;
drop policy if exists "divisions_delete_access" on public.divisions;
drop policy if exists "user_divisions_read_access" on public.user_divisions;
drop policy if exists "user_divisions_manage_access" on public.user_divisions;
drop policy if exists "user_permissions_read_access" on public.user_permissions;
drop policy if exists "user_permissions_manage_access" on public.user_permissions;
drop policy if exists "students_read_access" on public.students;
drop policy if exists "students_add_access" on public.students;
drop policy if exists "students_edit_access" on public.students;
drop policy if exists "students_delete_access" on public.students;
drop policy if exists "attendance_read_access" on public.attendance_records;
drop policy if exists "attendance_add_access" on public.attendance_records;
drop policy if exists "activity_logs_read_access" on public.activity_logs;
drop policy if exists "backup_jobs_access" on public.backup_jobs;

create policy "profiles_read_access" on public.profiles
for select using (
  id = auth.uid()
  or public.current_user_role() in ('owner', 'admin')
);

create policy "profiles_owner_manage" on public.profiles
for all using (public.current_user_role() = 'owner')
with check (public.current_user_role() = 'owner');

create policy "divisions_read_access" on public.divisions
for select using (
  public.has_permission('view_divisions', id)
);

create policy "divisions_add_access" on public.divisions
for insert with check (
  public.has_permission('add_divisions')
);

create policy "divisions_update_access" on public.divisions
for update using (
  public.current_user_role() in ('owner', 'admin')
)
with check (
  public.current_user_role() in ('owner', 'admin')
);

create policy "divisions_delete_access" on public.divisions
for delete using (
  public.has_permission('delete_divisions')
);

create policy "user_divisions_read_access" on public.user_divisions
for select using (
  user_id = auth.uid()
  or public.current_user_role() in ('owner', 'admin')
);

create policy "user_divisions_manage_access" on public.user_divisions
for all using (
  public.current_user_role() in ('owner', 'admin')
)
with check (
  public.current_user_role() in ('owner', 'admin')
);

create policy "user_permissions_read_access" on public.user_permissions
for select using (
  user_id = auth.uid()
  or public.current_user_role() in ('owner', 'admin')
);

create policy "user_permissions_manage_access" on public.user_permissions
for all using (
  public.current_user_role() in ('owner', 'admin')
)
with check (
  public.current_user_role() in ('owner', 'admin')
);

create policy "students_read_access" on public.students
for select using (
  public.has_permission('view_divisions', division_id)
);

create policy "students_add_access" on public.students
for insert with check (
  public.has_permission('add_students', division_id)
);

create policy "students_edit_access" on public.students
for update using (
  public.has_permission('edit_students', division_id)
)
with check (
  public.has_permission('edit_students', division_id)
);

create policy "students_delete_access" on public.students
for delete using (
  public.has_permission('delete_students', division_id)
);

create policy "attendance_read_access" on public.attendance_records
for select using (
  public.has_permission('view_attendance_history', division_id)
);

create policy "attendance_add_access" on public.attendance_records
for insert with check (
  public.has_permission('take_attendance', division_id)
  and exists (
    select 1
    from public.students s
    where s.id = attendance_records.student_id
      and s.division_id = attendance_records.division_id
  )
);

create policy "activity_logs_read_access" on public.activity_logs
for select using (
  public.has_permission('view_activity_logs')
);

create policy "backup_jobs_access" on public.backup_jobs
for all using (
  public.has_permission('manage_backups')
)
with check (
  public.has_permission('manage_backups')
);
