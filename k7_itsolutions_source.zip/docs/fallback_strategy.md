# Fallback Strategy

## 1. Remote build fallback
- Primary: GitHub Actions on `ubuntu-latest` for Android APK and `windows-latest` for Windows build.
- Secondary: Codemagic or another cloud build provider if GitHub Actions hits a genuine platform limitation.
- Tertiary: Manual upload to a cloud CI service after code is pushed to GitHub.

## 2. Database fallback
- Primary: Supabase Postgres.
- Secondary: A new Supabase project if the current project is not properly configured.
- Tertiary: Restore from SQL migration files if a configuration issue occurs.

## 3. Auth fallback
- Primary: Supabase Auth with email/password and role assignment.
- Secondary: Magic link or secure invitation flow if email/password is not preferred.

## 4. Storage fallback
- Primary: Supabase Storage for exports and backups.
- Secondary: GitHub release assets or a secure cloud backup service.

## 5. Recovery path
- Keep all migration files under version control.
- Keep RLS policies in source control.
- Keep a running troubleshooting log for every production issue.
- Validate recovery by restoring a snapshot and verifying student, attendance, and permission data.
