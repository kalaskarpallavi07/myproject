# Setup Guide

## 1. Prerequisites

This project is intended to be built remotely. You do not need local Flutter or Android tooling if you use GitHub Actions or Codemagic.

## 2. Supabase setup

1. Create a Supabase project.
2. Open the SQL editor.
3. Run `supabase/schema.sql`.
4. Run `supabase/rls.sql`.
5. Create the first owner user in the `auth.users` table and assign the `owner` role.
6. Configure SMTP or password-reset flows if needed.

## 3. Application configuration

The app is configured for the supplied Supabase project in
`apps/mobile/lib/core/constants.dart`. The app uses the Supabase publishable key,
which is intended for client applications and must be restricted by database
row-level security. Never put the service-role key in the app or GitHub.
Build-time `SUPABASE_URL` and `SUPABASE_ANON_KEY` dart-defines can override the
defaults when building for another project.

## 4. Remote build configuration

1. Push code to GitHub.
2. GitHub Actions will create the Flutter platform scaffolding, analyze and test
   the app, then build Android and Windows artifacts.

## 5. Roles and permissions

The application uses four roles:

- `owner`
- `admin`
- `sub_admin`
- `user`

Each role is enforced by database permissions. UI hiding alone is not enough.

## 6. Import and export

Use the Supabase SQL functions or generated CSV exports for bulk student import and export. For Excel files, convert to CSV before import.

## 7. Backup and restoration

Use the SQL dump and the Supabase backup features for point-in-time recovery. For local archives, store a copy in secure cloud storage.
