# Troubleshooting Log

## 2026-11-09

### Issue: Flutter SDK is not installed in the local environment
- Observation: `flutter --version` returned `not recognized as the name of a cmdlet`.
- Impact: Local build validation is unavailable on this machine.
- Decision: Do not install local SDKs because the requirement states no unnecessary local installations.
- Fallback: Use GitHub Actions and remote build services to create the APK and Windows executable.

### Issue: GitHub and Supabase login are still required for live cloud resources
- Observation: The app cannot call actual Supabase APIs until the user logs into their accounts and provides project credentials.
- Impact: Live table creation, auth setup, and secrets cannot be finalized without those credentials.
- Fallback: Use environment variables and GitHub repository secrets to inject the project URL and anon key; keep the service role key out of application code.

### Issue: Supabase RLS policy recurses
- Observation: A read-only REST request to `profiles` returned PostgreSQL error `42P17`, `infinite recursion detected in policy for relation "profiles"`.
- Cause: The original `profiles` policy queried `profiles` while evaluating access to `profiles`.
- Resolution prepared: `supabase/rls.sql` now uses `SECURITY DEFINER` helper functions and adds per-user permission rows.
- Validation: Applying the updated script through the dashboard returned PostgreSQL error `42601` at line 259. No successful application was confirmed; the SQL still needs correction and reapplication.

### Issue: GitHub push denied
- Observation: The remote repo is empty, but `git push` returned HTTP 403, `Permission to kalaskarpallavi07/myproject.git denied to chetankalaskar`.
- Cause: The saved local GitHub credentials belong to a different account than the repo owner and do not have write access.
- Resolution required: Authorize the correct GitHub account or grant the authenticated account repository write access, then retry the push.

### Issue: No local build tools
- Observation: Flutter, Dart, and `psql` are not available in the local environment.
- Resolution: Do not install them; use the configured GitHub Actions runners after the code is pushed.

## Critical development principle

The project remains valid and build-ready even when a local toolchain is unavailable. We preserve the source code and cloud automation so the final build can proceed remotely as soon as credentials are provided.
