# K7 ITsolutions

K7 ITsolutions is a cloud-first attendance management system for engineering colleges. It is designed as a single Flutter codebase that can run on Android and Windows while sharing the same Supabase database, authentication, roles, and synchronization rules.

## Core architecture

- Frontend: Flutter + Dart
- Database: Supabase PostgreSQL
- Auth and sync: Supabase Auth + Realtime
- Remote CI/CD: GitHub Actions for Android and Windows builds
- Storage: Supabase Storage for backups and exports

## Mandatory design

- White background, black text, thin black outlines
- Clean, professional dashboard
- Role-based permissions enforced at the database level via Supabase RLS
- No plain-text password storage
- All critical actions logged in audit tables

## Project structure

- `apps/mobile/` – Flutter app
- `supabase/` – schema and RLS policies
- `docs/` – setup and recovery documents
- `.github/workflows/` – remote build automation

## Quick start

1. Create a Supabase project.
2. Run the SQL in `supabase/schema.sql`.
3. Apply row-level security from `supabase/rls.sql`.
4. Update the Flutter app environment values in `apps/mobile/lib/core/constants.dart`.
5. Push the repo to GitHub and use the included workflow for remote builds.

## Remote build pipeline

GitHub Actions builds the Android APK and Windows desktop package in the cloud without requiring local Flutter, Android Studio, or Java SDK installation on the developer machine.

## Security summary

- Roles are stored in the `profiles` table and enforced by RLS.
- Service-role keys stay server-side only.
- Sensitive actions are tracked in audit tables.
- Temporary credentials require secure reset.

## Owner

Chetan Kalaskar

## Application identity

K7 ITsolutions is presented with a clean, simple identity, and the design system intentionally avoids decorative color usage so the UI stays professional and consistent.
