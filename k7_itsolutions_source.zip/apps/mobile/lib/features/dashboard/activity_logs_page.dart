import 'package:flutter/material.dart';

class ActivityLogsPage extends StatelessWidget {
  const ActivityLogsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final logs = [
      {'time': '09:15', 'user': 'owner', 'action': 'Created division C'},
      {'time': '10:20', 'user': 'admin', 'action': 'Updated student record'},
      {'time': '12:05', 'user': 'sub_admin', 'action': 'Marked attendance'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Activity Logs')),
      body: ListView.separated(
        padding: const EdgeInsets.all(24),
        itemCount: logs.length,
        separatorBuilder: (_, __) => const Divider(),
        itemBuilder: (context, index) {
          final log = logs[index];
          return ListTile(
            title: Text('${log['action']}'),
            subtitle: Text('${log['user']} at ${log['time']}'),
          );
        },
      ),
    );
  }
}
