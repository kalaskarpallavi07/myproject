import 'package:flutter/material.dart';

import '../../core/constants.dart';
import '../attendance/attendance_page.dart';
import '../settings/admin_settings_page.dart';
import '../students/student_management_page.dart';
import '../users/user_management_page.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  final List<_MenuItem> _items = const [
    _MenuItem('A Division', 'A'),
    _MenuItem('B Division', 'B'),
    _MenuItem('C Division', 'C'),
    _MenuItem('D Division', 'D'),
    _MenuItem('E Division', 'E'),
    _MenuItem('F Division', 'F'),
    _MenuItem('Manage Student Records', 'students'),
    _MenuItem('Manage Users', 'users'),
    _MenuItem('Attendance History', 'history'),
    _MenuItem('Activity Logs', 'logs'),
    _MenuItem('Backup and Restore', 'backup'),
    _MenuItem('Admin Settings', 'settings'),
    _MenuItem('Logout', 'logout'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.appName),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Text(
              AppConstants.ownerName,
              style: const TextStyle(fontWeight: FontWeight.w300),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 8),
            Expanded(
              child: GridView.builder(
                itemCount: _items.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 18,
                  crossAxisSpacing: 18,
                  childAspectRatio: 1.5,
                ),
                itemBuilder: (context, index) {
                  final item = _items[index];

                  return Material(
                    color: Colors.white,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () {
                        switch (item.route) {
                          case 'A':
                          case 'B':
                          case 'C':
                          case 'D':
                          case 'E':
                          case 'F':
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => AttendancePage(division: item.route),
                              ),
                            );
                            break;
                          case 'students':
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const StudentManagementPage(),
                              ),
                            );
                            break;
                          case 'users':
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const UserManagementPage(),
                              ),
                            );
                            break;
                          case 'settings':
                            Navigator.of(context).push(
                              MaterialPageRoute(
                                builder: (_) => const AdminSettingsPage(),
                              ),
                            );
                            break;
                          case 'logout':
                            Navigator.of(context).pop();
                            break;
                          default:
                            break;
                        }
                      },
                      child: Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(color: Colors.black, width: 1.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(
                          child: Text(
                            item.title,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuItem {
  const _MenuItem(this.title, this.route);

  final String title;
  final String route;
}
