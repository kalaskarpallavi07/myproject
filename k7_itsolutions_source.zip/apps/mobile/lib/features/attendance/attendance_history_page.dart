import 'package:flutter/material.dart';

class AttendanceHistoryPage extends StatelessWidget {
  const AttendanceHistoryPage({super.key});

  @override
  Widget build(BuildContext context) {
    final rows = [
      {'date': '2026-11-08', 'division': 'A', 'present': 32, 'absent': 8},
      {'date': '2026-11-07', 'division': 'B', 'present': 29, 'absent': 7},
      {'date': '2026-11-06', 'division': 'C', 'present': 35, 'absent': 5},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Attendance History')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: DataTable(
          columns: const [
            DataColumn(label: Text('Date')),
            DataColumn(label: Text('Division')),
            DataColumn(label: Text('Present')),
            DataColumn(label: Text('Absent')),
          ],
          rows: rows
              .map(
                (row) => DataRow(
                  cells: [
                    DataCell(Text('${row['date']}')),
                    DataCell(Text('${row['division']}')),
                    DataCell(Text('${row['present']}')),
                    DataCell(Text('${row['absent']}')),
                  ],
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
