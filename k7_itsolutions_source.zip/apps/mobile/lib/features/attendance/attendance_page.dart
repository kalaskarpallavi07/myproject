import 'package:flutter/material.dart';

import '../../models/student.dart';
import '../../services/attendance_service.dart';

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key, required this.division});

  final String division;

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  final controller = TextEditingController(text: '1,2,3,5,7,10,12');
  final students = <Student>[
    Student(id: 's1', rollNumber: 1, name: 'Aarav', division: 'A'),
    Student(id: 's2', rollNumber: 2, name: 'Bhavya', division: 'A'),
    Student(id: 's3', rollNumber: 3, name: 'Chetan', division: 'A'),
    Student(id: 's4', rollNumber: 4, name: 'Disha', division: 'A'),
    Student(id: 's5', rollNumber: 5, name: 'Esha', division: 'A'),
    Student(id: 's6', rollNumber: 6, name: 'Farah', division: 'A'),
    Student(id: 's7', rollNumber: 7, name: 'Gaurav', division: 'A'),
  ];

  String _result = '';

  void _generate() {
    final rollNumbers = AttendanceService.parsePresentRollNumbers(controller.text);
    final report = AttendanceService.generateAttendanceMarkup(
      division: widget.division,
      presentRollNumbers: rollNumbers,
      students: students,
    );

    setState(() => _result = report);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.division} Division')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              "Enter Present Students' Roll Numbers",
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 18),
            TextFormField(
              controller: controller,
              maxLines: 6,
              decoration: const InputDecoration(
                hintText: 'Example: 1,2,3,5,7,10,12',
              ),
            ),
            const SizedBox(height: 18),
            ElevatedButton(
              onPressed: _generate,
              child: const Text('GENERATE ATTENDANCE'),
            ),
            const SizedBox(height: 24),
            if (_result.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.black, width: 1.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: SelectableText(_result),
              ),
          ],
        ),
      ),
    );
  }
}
