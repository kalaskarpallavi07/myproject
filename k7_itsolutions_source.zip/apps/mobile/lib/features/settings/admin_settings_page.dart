import 'package:flutter/material.dart';

class AdminSettingsPage extends StatefulWidget {
  const AdminSettingsPage({super.key});

  @override
  State<AdminSettingsPage> createState() => _AdminSettingsPageState();
}

class _AdminSettingsPageState extends State<AdminSettingsPage> {
  bool backupEnabled = true;
  bool rlsEnabled = true;
  bool notificationsEnabled = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin Settings')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView(
          children: [
            SwitchListTile(
              title: const Text('Automatic backup'),
              value: backupEnabled,
              onChanged: (value) => setState(() => backupEnabled = value),
            ),
            SwitchListTile(
              title: const Text('Enable RLS enforcement'),
              value: rlsEnabled,
              onChanged: (value) => setState(() => rlsEnabled = value),
            ),
            SwitchListTile(
              title: const Text('Attendance notifications'),
              value: notificationsEnabled,
              onChanged: (value) => setState(() => notificationsEnabled = value),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: const Text('SAVE CHANGES'),
            ),
          ],
        ),
      ),
    );
  }
}
