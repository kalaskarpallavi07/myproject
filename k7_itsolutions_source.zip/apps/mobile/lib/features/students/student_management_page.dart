import 'package:flutter/material.dart';

class StudentManagementPage extends StatelessWidget {
  const StudentManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    const students = [
      {'roll': 1, 'name': 'Aarav', 'division': 'A'},
      {'roll': 2, 'name': 'Bhavya', 'division': 'B'},
      {'roll': 3, 'name': 'Chetan', 'division': 'C'},
      {'roll': 4, 'name': 'Disha', 'division': 'D'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Manage Student Records')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(
                hintText: 'Search students',
              ),
            ),
            const SizedBox(height: 18),
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(
                onPressed: () {},
                child: const Text('ADD STUDENT'),
              ),
            ),
            const SizedBox(height: 18),
            Expanded(
              child: SingleChildScrollView(
                child: DataTable(
                  columns: const [
                    DataColumn(label: Text('Roll')),
                    DataColumn(label: Text('Name')),
                    DataColumn(label: Text('Division')),
                    DataColumn(label: Text('Action')),
                  ],
                  rows: students
                      .map(
                        (student) => DataRow(
                          cells: [
                            DataCell(Text('${student['roll']}')),
                            DataCell(Text('${student['name']}')),
                            DataCell(Text('${student['division']}')),
                            DataCell(Row(
                              children: const [
                                Icon(Icons.edit),
                                SizedBox(width: 8),
                                Icon(Icons.delete),
                              ],
                            )),
                          ],
                        ),
                      )
                      .toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
