import 'package:flutter/material.dart';

class UserManagementPage extends StatelessWidget {
  const UserManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    final users = [
      {'name': 'Owner', 'email': 'owner@k7.com', 'role': 'owner'},
      {'name': 'Admin', 'email': 'admin@k7.com', 'role': 'admin'},
      {'name': 'Sub-admin', 'email': 'subadmin@k7.com', 'role': 'sub_admin'},
      {'name': 'User', 'email': 'user@k7.com', 'role': 'user'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Manage Users')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: DataTable(
          columns: const [
            DataColumn(label: Text('Name')),
            DataColumn(label: Text('Email')),
            DataColumn(label: Text('Role')),
          ],
          rows: users
              .map(
                (user) => DataRow(
                  cells: [
                    DataCell(Text('${user['name']}')),
                    DataCell(Text('${user['email']}')),
                    DataCell(Text('${user['role']}')),
                  ],
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
