import '../models/student.dart';

class AttendanceService {
  static List<int> parsePresentRollNumbers(String input) {
    if (input.trim().isEmpty) {
      return const [];
    }

    final values = input.split(',');
    final numbers = <int>[];

    for (final value in values) {
      final trimmed = value.trim();
      final parsed = int.tryParse(trimmed);
      if (parsed != null) {
        numbers.add(parsed);
      }
    }

    return numbers;
  }

  static String generateAttendanceMarkup({
    required String division,
    required List<int> presentRollNumbers,
    required List<Student> students,
  }) {
    final presentSet = presentRollNumbers.toSet();
    final lines = <String>['DIVISION: $division'];

    for (final student in students) {
      final present = presentSet.contains(student.rollNumber);
      lines.add('${student.rollNumber},${student.name},${present ? 'P' : 'A'}');
    }

    return lines.join('\n');
  }
}
