import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  SupabaseService._();

  static final SupabaseService instance = SupabaseService._();

  SupabaseClient get client => Supabase.instance.client;

  Future<List<String>> fetchAssignedDivisions() async {
    final userId = client.auth.currentUser?.id;
    if (userId == null) {
      return const [];
    }

    final response = await client
        .from('user_divisions')
        .select('division_id')
        .eq('user_id', userId);

    if (response is List) {
      return response
          .map((item) => item['division_id']?.toString() ?? '')
          .where((division) => division.isNotEmpty)
          .toList();
    }

    return const [];
  }

  Future<List<Map<String, dynamic>>> fetchDivisions() async {
    final response = await client.from('divisions').select();
    if (response is List) {
      return response.cast<Map<String, dynamic>>();
    }
    return const [];
  }
}
