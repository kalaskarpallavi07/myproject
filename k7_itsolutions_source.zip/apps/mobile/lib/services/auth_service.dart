import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/user_profile.dart';

class AuthService {
  SupabaseClient get _client => Supabase.instance.client;

  Future<bool> signIn({required String email, required String password}) async {
    final response = await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
    return response.user != null;
  }

  Future<UserProfile?> getCurrentProfile() async {
    final user = _client.auth.currentUser;
    if (user == null) {
      return null;
    }

    final response = await _client
        .from('profiles')
        .select()
        .eq('id', user.id)
        .maybeSingle();

    if (response == null) {
      return UserProfile(
        id: user.id,
        email: user.email ?? '',
        fullName: user.userMetadata?['full_name']?.toString() ?? 'User',
        role: UserRole.user,
        assignedDivisions: const [],
      );
    }

    return UserProfile.fromJson(response);
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
  }
}
