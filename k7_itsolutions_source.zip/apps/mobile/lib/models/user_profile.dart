enum UserRole {
  owner,
  admin,
  subAdmin,
  user,
}

class UserProfile {
  UserProfile({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    required this.assignedDivisions,
  });

  final String id;
  final String email;
  final String fullName;
  final UserRole role;
  final List<String> assignedDivisions;

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    final roleValue = json['role'] as String? ?? 'user';

    return UserProfile(
      id: json['id']?.toString() ?? '',
      email: json['email']?.toString() ?? '',
      fullName: json['full_name']?.toString() ?? 'User',
      role: UserRole.values.firstWhere(
        (element) => element.name == roleValue,
        orElse: () => UserRole.user,
      ),
      assignedDivisions: (json['assigned_divisions'] as List<dynamic>? ?? const [])
          .map((item) => item.toString())
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'full_name': fullName,
      'role': role.name,
      'assigned_divisions': assignedDivisions,
    };
  }

  bool hasPermission(String permission) {
    switch (role) {
      case UserRole.owner:
        return true;
      case UserRole.admin:
        return true;
      case UserRole.subAdmin:
        return const {
          'add_students',
          'edit_students',
          'delete_students',
          'view_assigned_divisions',
          'take_attendance',
        }.contains(permission);
      case UserRole.user:
        return const {
          'view_assigned_divisions',
          'take_attendance',
          'generate_absent_rolls',
          'generate_binary_attendance',
          'generate_whatsapp_messages',
          'copy_attendance_outputs',
        }.contains(permission);
    }
  }
}
