class Student {
  Student({
    required this.id,
    required this.rollNumber,
    required this.name,
    required this.division,
    this.isActive = true,
    this.admissionDate,
  });

  final String id;
  final int rollNumber;
  final String name;
  final String division;
  final bool isActive;
  final DateTime? admissionDate;

  factory Student.fromJson(Map<String, dynamic> json) {
    return Student(
      id: json['id']?.toString() ?? '',
      rollNumber: int.tryParse(json['roll_number']?.toString() ?? '') ?? 0,
      name: json['student_name']?.toString() ?? '',
      division: json['division']?.toString() ?? 'A',
      isActive: json['is_active'] as bool? ?? true,
      admissionDate: json['admission_date'] != null
          ? DateTime.tryParse(json['admission_date'].toString())
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'roll_number': rollNumber,
      'student_name': name,
      'division': division,
      'is_active': isActive,
      'admission_date': admissionDate?.toIso8601String(),
    };
  }
}
