import 'package:flutter/material.dart';

import 'core/theme/app_theme.dart';
import 'features/auth/login_page.dart';

class K7App extends StatelessWidget {
  const K7App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'K7 ITsolutions',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: const LoginPage(),
    );
  }
}
