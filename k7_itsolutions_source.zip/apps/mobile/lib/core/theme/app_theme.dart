import 'package:flutter/material.dart';

class AppTheme {
  static ThemeData light() {
    const color = Colors.black;
    const surface = Colors.white;
    const outline = Color(0xFF111111);

    return ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: surface,
      primaryColor: color,
      colorScheme: const ColorScheme.light(
        primary: color,
        onPrimary: Colors.white,
        secondary: color,
        surface: surface,
        onSurface: color,
        outline: outline,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: surface,
        foregroundColor: color,
        elevation: 0,
        centerTitle: true,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: false,
        border: OutlineInputBorder(
          borderSide: const BorderSide(color: outline, width: 1.2),
          borderRadius: BorderRadius.circular(12),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: outline, width: 1.2),
          borderRadius: BorderRadius.circular(12),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: const BorderSide(color: outline, width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          side: const BorderSide(color: outline, width: 1.2),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: Colors.black,
        ),
      ),
      dividerTheme: const DividerThemeData(
        color: Colors.black12,
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontWeight: FontWeight.w700,
          color: color,
        ),
        titleLarge: TextStyle(
          fontWeight: FontWeight.w600,
          color: color,
        ),
        bodyLarge: TextStyle(
          color: color,
        ),
        bodyMedium: TextStyle(
          color: color,
        ),
      ),
    );
  }
}
