class AppConstants {
  static const String appName = 'K7 ITsolutions';
  static const String ownerName = 'Chetan Kalaskar';

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://ftmgwzwwefjwbxgtmwgi.supabase.co',
  );

  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_AOVxnOvWIMZCEda8Zbr2cQ_xcJ0hTF5',
  );
}

const String kSupabaseUrl = AppConstants.supabaseUrl;
const String kSupabaseAnonKey = AppConstants.supabaseAnonKey;
