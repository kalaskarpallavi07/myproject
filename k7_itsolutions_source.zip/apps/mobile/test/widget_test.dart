import 'package:flutter_test/flutter_test.dart';
import 'package:k7_itsolutions/app.dart';

void main() {
  testWidgets('K7 app renders startup screen', (tester) async {
    await tester.pumpWidget(const K7App());

    expect(find.text('K7 ITsolutions'), findsOneWidget);
  });
}
